' Inicio de la app
sub Main(args as Object)
    'Indicate this is a Roku SceneGraph application'
    screen = CreateObject("roSGScreen")
    m.port = CreateObject("roMessagePort")
    screen.setMessagePort(m.port)
    ' Inicializa el monitoreo de memoria recomendado por Roku
    InitMemoryMonitoring(m.port)
    m.runtimeClock = CreateObject("roTimespan")
    m.runtimeClock.Mark()
    printLog("Application started; diagnostic heartbeat enabled every 60 seconds.")

    if args <> invalid
        if args.reason <> invalid then
        end if
        
        if args.contentID <> invalid then
            m.contentID = args.contentID
        end if
    end if

    'Create a scene and load /components/MainScene.xml'
    scene = screen.CreateScene("MainScene")
    screen.show()

    'observe the appExit event to know when to kill the channel
    scene.observeField("appExit", m.port)
    'focus the scene so it can respond to key events
    scene.setFocus(true)

    while(true)
        ' El timeout permite emitir diagnósticos aunque no lleguen eventos al puerto.
        msg = wait(1000, m.port)
        msgType = type(msg)

        if m.runtimeClock.TotalSeconds() >= 60 then
            LogMemorySnapshot("heartbeat")
            m.runtimeClock.Mark()
        end if

        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then
                printLog("Main loop exiting: SceneGraph screen closed.")
                return
            end if
        'respond to the appExit field on MainScene
        else if HandleSystemEvents(msg)
            ' Evento de sistema/memoria ya gestionado

        else if msgType = "roSGNodeEvent" then
            field = msg.getField()
            'if the scene's appExit field was changed in any way, exit the channel
            if field = "appExit" then
                printLog("Main loop exiting: appExit requested by MainScene.")
                return
            end if
        end if
    end while
end sub

sub InitMemoryMonitoring(port as Object)
    ' Monitor específico de memoria de la app/canal
    m.memMon = CreateObject("roAppMemoryMonitor")
    memMonIf = invalid
    if m.memMon <> invalid then
        ' Verifica que la interfaz exista para compatibilidad con distintas versiones de OS
        memMonIf = GetInterface(m.memMon, "ifAppMemoryMonitor")
        if memMonIf <> invalid then
            ' Enlaza el monitor al mismo puerto del loop principal
            m.memMon.SetMessagePort(port)
            ' Habilita warnings cuando el canal entra en presión de memoria
            m.memMon.EnableMemoryWarningEvent(true)

            ' Snapshot inicial de memoria para diagnóstico en logs
            m.lastMemorySnapshot = LogMemorySnapshot("startup")
        end if
    end if

    ' Eventos de memoria general del dispositivo (no solo del canal)
    m.devInfo = CreateObject("roDeviceInfo")
    if m.devInfo <> invalid then
        m.devInfo.SetMessagePort(port)
        ' Habilita notificación cuando el sistema reporta memoria general baja
        m.devInfo.EnableLowGeneralMemoryEvent(true)
    end if
end sub

function HandleSystemEvents(msg as Object) as Boolean
    msgType = type(msg)
    if msgType = "roAppMemoryMonitorEvent" then
        ' Punto ideal para degradación controlada: limpiar cachés, liberar imágenes pesadas, etc.

        if m.memMon <> invalid then
            ' Snapshot al momento del warning para entender severidad
            snapshot = LogMemorySnapshot("warning")

            ' Presión de memoria alta: fuerza GC para liberar objetos no referenciados.
            if snapshot <> invalid and snapshot.memoryLimitPercent >= 85 then
                printLog("High memory pressure detected (" + snapshot.memoryLimitPercent.toStr() + "%). Triggering garbage collection.")
                RunGarbageCollector()
            end if
        end if
        return true
    else if msgType = "roDeviceInfoEvent" then
        ' Evento de memoria general del sistema
        info = msg.GetInfo()
        if info <> invalid and info.generalMemoryLevel <> invalid then
            printLog("Low general memory event - level: " + info.generalMemoryLevel.toStr())
        else
            printLog("Device info event received without generalMemoryLevel data.")
        end if
        return true
    end if

    return false
end function

function LogMemorySnapshot(context as String) as Dynamic
    if m.memMon = invalid then return invalid

    channelAvailableMemory = m.memMon.GetChannelAvailableMemory()
    channelMemoryLimit = m.memMon.GetChannelMemoryLimit()
    memoryLimitPercent = m.memMon.GetMemoryLimitPercent()

    snapshot = {
        context: context
        channelAvailableMemory: channelAvailableMemory
        channelMemoryLimit: channelMemoryLimit
        memoryLimitPercent: memoryLimitPercent
    }

    m.lastMemorySnapshot = snapshot
    printLog("Memory snapshot [" + context + "] - available: " + channelAvailableMemory.toStr() + " bytes, usage: " + memoryLimitPercent.toStr() + "%")
    return snapshot
end function
