' Inicialización del componente (parte del ciclo de vida de Roku)
sub init()
    m.background = m.top.findNode("background")
    m.carouselContainer = m.top.findNode("carouselContainer")
    m.guideContainer = m.top.findNode("guideContainer")
    m.carouselGuide = m.top.findNode("carouselGuide")
    m.carouselGuideContainer = m.top.findNode("carouselGuideContainer")

    m.detailGuideContainer = m.top.findNode("detailGuideContainer")

    m.programSummaryPlayer = m.top.findNode("programSummaryPlayer")

    m.prevChannelNumber = m.top.findNode("prevChannelNumber")
    m.prevChannelImage = m.top.findNode("prevChannelImage")
    
    m.currentChannelContainer = m.top.findNode("currentChannelContainer")
    m.currentChannelNumber = m.top.findNode("currentChannelNumber")
    m.currentChannelImage = m.top.findNode("currentChannelImage")

    m.nextChannelNumber = m.top.findNode("nextChannelNumber")
    m.nextChannelImage = m.top.findNode("nextChannelImage")
    
    m.selectedIndicator = m.top.findNode("selectedIndicator")
    m.channelContainer = m.top.findNode("channelContainer")
    m.guideGroup = m.top.findNode("guideGroup")

    m.arrowUp = m.top.findNode("arrowUp")
    m.arrowDown = m.top.findNode("arrowDown")

    m.prevContainer = m.top.findNode("prevContainer")
    m.nextChannelContainer = m.top.findNode("nextChannelContainer")
    
    m.changeUp = m.top.findNode("changeUp")
    m.changeDown = m.top.findNode("changeDown")

    m.scaleInfo = m.global.scaleInfo
    
    m.loadConfig = false
    m.saveDateByEvent = false
    m.carouselGuideEventsObserved = false
    m.noProgram = false
    m.channelArray = []

    m.nextCarouselGuide = invalid
    m.currentCarouselGuide = invalid
    m.prevCarouselGuide = invalid

    m.programDetailComponent = invalid
    m.emissionsComponent = invalid

    m.nextChannel = invalid
    m.currentChannel = invalid
    m.prevChannel = invalid
    m.isNowPosition = true
    m.dateTimeByPosition = invalid
    m.lastElementSelect = invalid

    m.indexPosition = 0
    m.currentCatchupHours = 0

    m.separator = scaleValue(15, m.scaleInfo)
    m.size = scaleSize([160, 262], m.scaleInfo)
    m.xInitial = scaleValue(-150, m.scaleInfo)
    m.targetItems = 8

    m.targetRects = createTargetRects(m.targetItems, m.xInitial, (m.size[0] + m.separator), m.size[0], m.size[1])
    __removeProgramDetailComponent()
end sub

' Funcion que interpreta los eventos de teclado y retorna true si fue porcesada por este componente. Sino es porcesado por el
' entonces sigue con el siguente metodo onKeyEvent del compoente superior
function onKeyEvent(key as string, press as boolean) as boolean

    handled = false

    if key = KeyButtons().UP then 
        if press then 
            m.programBySend = invalid
            
            m.top.channelIdIndexOf = m.top.channelIdIndexOf - 1
    
            if m.top.channelIdIndexOf < 0 then m.top.channelIdIndexOf = m.channelArray.count() - 1 

            prevIndex = m.top.channelIdIndexOf - 1 
            nextIndex = m.top.channelIdIndexOf + 1

            if prevIndex < 0 then prevIndex = m.channelArray.count() - 1
            if nextIndex > m.channelArray.count() - 1 then prevIndex = 0

            m.nextChannel = m.currentChannel
            __updateChannelInfo(m.nextChannel, m.nextChannelNumber, m.nextChannelImage)

            m.currentChannel = m.prevChannel

             m.top.channelId = m.currentChannel.id

            __updateChannelInfo(m.currentChannel, m.currentChannelNumber, m.currentChannelImage)

            if m.channelArray[prevIndex] <> invalid then 
                m.prevChannel = m.channelArray[prevIndex]
                __updateChannelInfo(m.prevChannel, m.prevChannelNumber, m.prevChannelImage)
            end if

            __savePosition()

            m.currentChannelNumber.setFocus(true)

            clearTimer(m.changeUp)
            
            m.changeUp.ObserveField("fire","onLoadChangeChannelUp")
            m.changeUp.control = "start"
        end if

        handled = true 

    else if key = KeyButtons().DOWN then
        if press then 
            m.programBySend = invalid

            m.top.channelIdIndexOf = m.top.channelIdIndexOf + 1
    
            if m.top.channelIdIndexOf > m.channelArray.count() - 1 then m.top.channelIdIndexOf = 0 

            prevIndex = m.top.channelIdIndexOf - 1 
            nextIndex = m.top.channelIdIndexOf + 1

            if prevIndex < 0 then prevIndex = m.channelArray.count() - 1
            if nextIndex > m.channelArray.count() - 1 then prevIndex = 0

            m.prevChannel = m.currentChannel
            __updateChannelInfo(m.prevChannel, m.prevChannelNumber, m.prevChannelImage)

            m.currentChannel = m.nextChannel

            m.top.channelId = m.currentChannel.id

            __updateChannelInfo(m.currentChannel, m.currentChannelNumber, m.currentChannelImage)
                
            if m.channelArray[nextIndex] <> invalid then 
                m.nextChannel = m.channelArray[nextIndex]
                __updateChannelInfo(m.nextChannel, m.nextChannelNumber, m.nextChannelImage)
            end if

            __savePosition()

            m.currentChannelNumber.setFocus(true)
            
            clearTimer(m.changeDown)
            
            m.changeDown.ObserveField("fire","onLoadChangeChannelDown")
            m.changeDown.control = "start"
        end if

        handled = true 
    
    else if key = KeyButtons().OK then
        if press then
            if m.currentChannel <> invalid and m.currentChannelNumber <> invalid and m.currentChannelNumber.isInFocusChain() and m.isNowPosition then 
                __channelSelected()
            end if  
        end if 
        
        handled = true 

    else if key = KeyButtons().LEFT or key = KeyButtons().RIGHT then
        if press then
            if m.currentChannelNumber.isInFocusChain() and m.carouselGuide <> invalid and m.carouselGuide.content <> invalid then 
                m.carouselGuide.setFocus(true)
            end if  
        end if 
        
        handled = true 

    else if key = KeyButtons().BACK then

        if m.detailGuideContainer.isInFocusChain() then 
            if press then
                __removeProgramDetailComponent()
                m.carouselGuide.setFocus(true)
            end if 
            
            handled = true 
        end if 

        if not handled and press then
            clearTimer(m.changeUp)
            clearTimer(m.changeDown)

            m.apiRequestCurrentChannel = clearApiRequest(m.apiRequestCurrentChannel)
            m.apiRequestPrevChannel = clearApiRequest(m.apiRequestPrevChannel)
            m.apiRequestNextChannel = clearApiRequest(m.apiRequestNextChannel)

            m.currentCatchupHours = 0
            m.programSummaryPlayer.catchupDuration =  m.currentCatchupHours
            m.programSummaryPlayer.program = invalid

            m.carouselGuide.targetSet = invalid
            m.carouselGuide.content = invalid
            m.top.channelIdIndexOf = -1
            m.nextChannel = invalid
            m.currentChannel = invalid
            m.prevChannel = invalid
            m.isNowPosition = true
            m.indexPosition = 0
            m.dateTimeByPosition = invalid
            m.lastElementSelect = invalid
                
            m.selectedIndicator.visible = false

            m.nextCarouselGuide = invalid
            m.currentCarouselGuide = invalid
            m.prevCarouselGuide = invalid

            m.saveDateByEvent = false

            m.prevChannelNumber.text = ""
            m.prevChannelImage.uri = ""
                
            m.currentChannelNumber.text = ""
            m.currentChannelImage.uri = ""
                
            m.nextChannelNumber.text = ""
            m.nextChannelImage.uri = ""
        end if 

    end if 

    return handled
end function

' Carga la lista de canales.
sub loadChannelArray()
    if not m.loadConfig then __initConfig()

    if m.top.items <> invalid and m.top.items.count() > 0 then 
        m.channelArray = m.top.items
        __searchChannel()
    else 
        __clearGuide()
    end if
end sub

' Posiciona el el foco sobre el canal que concuerda con el Id pasado
sub onShowPositioninChannelId()
    if m.top.positioninChannelId then
        m.top.positioninChannelId = false
        if m.currentChannel <> invalid then
            ' En caso de que el id del canal, sea diferente al canals seleccionado, actualizar el canarl
            if m.currentChannel.id <> m.top.channelId and m.channelArray <> invalid then
                for i = 0 to m.channelArray.count() - 1
                    if m.channelArray[i].id = m.top.channelId then
                        m.top.channelIdIndexOf = i
                    end if
                end for

                m.currentChannel = m.channelArray[m.top.channelIdIndexOf]
            end if 
            m.currentChannelNumber.setFocus(true)
            __searchCurrentChannel()
        end if
    end if
end sub

' Dispara la busqueda de la posicion del canal.  
sub onSearchChannelPosition()
    if m.top.searchChannelPosition then
        m.top.searchChannelPosition = false
        __searchChannel()
    end if
end sub

' Se posiciona la guia en el canal recibido por Id.
sub positionChannel()
    if m.top.channelId <> 0 then __searchChannel()
end sub

' Procesa la respuesta de la guia del canal actual
sub onCurrentCarouselResponse()
    if validateStatusCode(m.apiRequestCurrentChannel.statusCode) then 
        m.currentCarouselGuide = ParseJson(m.apiRequestCurrentChannel.response)

         if m.apiRequestCurrentChannel.dataAux <> invalid and m.apiRequestCurrentChannel.dataAux <> "" then
            m.currentCarouselGuide.channelId = ParseJson(m.apiRequestCurrentChannel.dataAux).channelId
        end if 

        m.apiRequestCurrentChannel = clearApiRequest(m.apiRequestCurrentChannel)

        if m.currentCarouselGuide <> invalid and m.currentCarouselGuide.data <> invalid then
            if m.currentCarouselGuide.data.catchupDuration <> invalid then 
                m.currentCatchupHours = m.currentCarouselGuide.data.catchupDuration
            else 
                m.currentCatchupHours = 0
            end if

            m.programSummaryPlayer.catchupDuration = m.currentCatchupHours

            __processAndLoadCarousel(m.currentCarouselGuide.data.programs)
            __searchPrevChannel()
            __searchNextChannel()
        end if
    else
        error = m.apiRequestCurrentChannel.errorResponse
        statusCode = m.apiRequestCurrentChannel.statusCode
        m.apiRequestCurrentChannel = clearApiRequest(m.apiRequestCurrentChannel) 

        printError("Guide (CurrentCarousel):", error)

        if validateLogout(statusCode, m.top) then return
    end if
end sub

' Procesa la respuesta de la guia del canal anterior
sub onPrevCarouselResponse()
    if validateStatusCode(m.apiRequestPrevChannel.statusCode) then
        m.prevCarouselGuide = ParseJson(m.apiRequestPrevChannel.response)

        if m.apiRequestPrevChannel.dataAux <> invalid and m.apiRequestPrevChannel.dataAux <> "" then
            m.prevCarouselGuide.channelId = ParseJson(m.apiRequestPrevChannel.dataAux).channelId
        end if 

        m.apiRequestPrevChannel = clearApiRequest(m.apiRequestPrevChannel)
    else
        error = m.apiRequestPrevChannel.errorResponse
        statusCode = m.apiRequestPrevChannel.statusCode
        m.apiRequestPrevChannel = clearApiRequest(m.apiRequestPrevChannel) 

        printError("Guide (PrevCarousel):", error)

        if validateLogout(statusCode, m.top) then return
    end if
end sub

' Procesa la respuesta de la guia del canal siguiente
sub onNextCarouselResponse()
    if validateStatusCode(m.apiRequestNextChannel.statusCode) then 
        m.nextCarouselGuide = ParseJson(m.apiRequestNextChannel.response)

        if m.apiRequestNextChannel.dataAux <> invalid and m.apiRequestNextChannel.dataAux <> "" then
            m.nextCarouselGuide.channelId = ParseJson(m.apiRequestNextChannel.dataAux).channelId
        end if 

        m.apiRequestNextChannel = clearApiRequest(m.apiRequestNextChannel)
    else
        error = m.apiRequestNextChannel.errorResponse
        statusCode = m.apiRequestNextChannel.statusCode
        m.apiRequestNextChannel = clearApiRequest(m.apiRequestNextChannel) 

        printError("Guide (NextCarousel):", error)

        if validateLogout(statusCode, m.top) then return
    end if
end sub

' Devuelve el nodo que se a seleccionado
sub onItemSelectedChanged()
    indexSelected = m.carouselGuide.itemSelected
    programNode = m.carouselGuide.content.getChild(indexSelected)
    
    loadToPLayer = false

    nowDate = CreateObject("roDateTime")
    nowDate.ToLocalTime()
    nowSeconds = nowDate.AsSeconds()
    
    catchupDate = CreateObject("roDateTime")
    catchupDate.ToLocalTime()
    catchupDateSeconds = catchupDate.AsSeconds()
    catchupDateSeconds = catchupDateSeconds - (m.currentCatchupHours * 60 * 60) ' el catchup llega en horas 
    
    if (((programNode.startSeconds = invalid or programNode.startSeconds = 0) and (programNode.endSeconds = invalid or programNode.endSeconds = 0)) or (programNode.startSeconds <= nowSeconds and programNode.endSeconds >= nowSeconds)) then 
        ' Programa en vivo
        loadToPLayer = true
    else if m.currentCatchupHours <> 0 and catchupDateSeconds <= programNode.endSeconds and programNode.endSeconds <= nowSeconds then
        ' Programa catchup
        if m.global.contact.forTest = invalid or (m.global.contact.forTest <> invalid and not m.global.contact.forTest) then 
            loadToPLayer = true
        end if
    end if

    if loadToPLayer then 
        if programNode <> invalid and programNode.parentalControl <> invalid and programNode.parentalControl then 
            if m.carouselGuide.focusedChild <> invalid then m.lastElementSelect = m.carouselGuide.focusedChild
            if m.pinDialog <> invalid then 
                clearPINDialogAndGetOption(m.top, m.pinDialog)
                m.pinDialog = invalid
            end if
            m.programBySend = m.currentCarouselGuide.data.programs[indexSelected]
            m.pinDialog = createAndShowPINDialog(m.top, i18n_t(m.global.i18n, "shared.parentalControlModal.title"), "onPinDialogLoad", [i18n_t(m.global.i18n, "button.ok"), i18n_t(m.global.i18n, "button.cancel")])
        else
            m.programBySend = m.currentCarouselGuide.data.programs[indexSelected]
            __loadStreamingForPlayer()
        end if
    else 
        if m.global.contact.forTest = invalid or (m.global.contact.forTest <> invalid and not m.global.contact.forTest) then
            m.programBySend = m.currentCarouselGuide.data.programs[indexSelected]
            __loadDetail()
        end if
    end if 
end sub

' devuelve el nodo que esta teniendo el foco.
sub onItemFocusedChanged()
    ' Cuando el PIN esta abierto, el foco puede cambiar dentro del dialogo y disparar
    ' itemFocused nuevamente. No debemos limpiar m.programBySend porque contiene
    ' el programa que se debe reproducir si la validacion parental es correcta.
    'if not isPINDialogVisible() then m.programBySend = invalid
    m.programSummaryPlayer.program = m.carouselGuide.content.getChild(m.carouselGuide.itemFocused)
end sub

' Procesa el evento de flecha izquierda
sub onLeftEvent()
    if m.currentChannel <> invalid and m.currentChannel.program <> invalid then
        if m.carouselGuide.happenedLeft then m.saveDateByEvent = true
    end if
end sub

' Procesa el evento de flecha derecha
sub onRightEvent()
    if m.currentChannel <> invalid and m.currentChannel.program <> invalid then
        if m.carouselGuide.happenedRight then m.saveDateByEvent = true  
    end if
end sub

' Dispara la carga de la guia del canal superior
sub onLoadChangeChannelUp()
    clearTimer(m.changeUp)

    if m.prevCarouselGuide <> invalid and m.prevCarouselGuide.channelId = m.currentChannel.id then 
        m.nextCarouselGuide = m.currentCarouselGuide
        m.currentCarouselGuide = m.prevCarouselGuide
        m.prevCarouselGuide = invalid

        if m.currentCarouselGuide <> invalid and m.currentCarouselGuide.data <> invalid then
            if m.currentCarouselGuide.data.catchupDuration <> invalid then 
                m.currentCatchupHours = m.currentCarouselGuide.data.catchupDuration
            else 
                m.currentCatchupHours = 0
            end if

            m.programSummaryPlayer.catchupDuration = m.currentCatchupHours

            __processAndLoadCarousel(m.currentCarouselGuide.data.programs)
            __searchPrevChannel()
        end if
    else 
        ' Se fue a mas de un salto 
        __searchCurrentChannel()
    end if
end sub

' Dispara la carga de la guia del canal inferior
sub onLoadChangeChannelDown()
    clearTimer(m.changeDown)

    if m.nextCarouselGuide <> invalid and m.nextCarouselGuide.channelId = m.currentChannel.id then 
        m.prevCarouselGuide = m.currentCarouselGuide
        m.currentCarouselGuide = m.nextCarouselGuide
        m.nextCarouselGuide = invalid

        if m.currentCarouselGuide <> invalid and m.currentCarouselGuide.data <> invalid then
            if m.currentCarouselGuide.data.catchupDuration <> invalid then 
                m.currentCatchupHours = m.currentCarouselGuide.data.catchupDuration
            else 
                m.currentCatchupHours = 0
            end if

            m.programSummaryPlayer.catchupDuration = m.currentCatchupHours
   
            __processAndLoadCarousel(m.currentCarouselGuide.data.programs)
            __searchNextChannel()
        end if
    else 
        ' Se fue a mas de un salto 
        __searchCurrentChannel()
    end if
end sub

' Se dispara la validacion del PIN cargado en el modal
sub onPinDialogLoad()
  resp = clearPINDialogAndGetOption(m.top, m.pinDialog)
  m.pinDialog = invalid
  
  if (resp.option = 0 and resp.pin <> invalid and Len(resp.pin) = 4) then 
    ' if m.lastElementSelect <> invalid then m.lastElementSelect.setFocus(true)
    m.apiRequestManager = sendApiRequest(m.apiRequestManager, urlParentalControlPin(resp.pin), "GET", "onParentalControlResponse")
  else 
    m.repositionChannnelList = true
    if m.lastElementSelect <> invalid then m.lastElementSelect.setFocus(true)
  end if 
end sub

' Procesa la respuesta de la validacion del PIN
sub onParentalControlResponse()
    m.top.loading.visible = false
    if validateStatusCode(m.apiRequestManager.statusCode) then
        resp = ParseJson(m.apiRequestManager.response)

        if resp <> invalid and resp.data <> invalid and resp.data then
            __loadStreamingForPlayer()
        else
            if m.lastElementSelect <> invalid then m.lastElementSelect.setFocus(true)
            if m.dialog <> invalid then
                clearDialogAndGetOption(m.top, m.dialog)
                m.dialog = invalid 
            end if
            m.dialog = createAndShowDialog(m.top, i18n_t(m.global.i18n, "shared.parentalControlModal.error.invalid"), i18n_t(m.global.i18n, "shared.parentalControlModal.error.description"), "onDialogClosedLastFocus")
        end if
    else     
        statusCode = m.apiRequestManager.statusCode
        errorResponse = m.apiRequestManager.errorResponse
        m.apiRequestManager = clearApiRequest(m.apiRequestManager)

        printError("ParentalControl:", statusCode.toStr() + " " +  errorResponse)

        if validateLogout(statusCode, m.top) then return
    end if
end sub

' Hace foco en objeto que lo tenia antes de que se abriera el modal
sub onDialogClosedLastFocus()
  option = clearDialogAndGetOption(m.top, m.dialog)
  m.dialog = invalid
  
  if option = 0 then
    if m.lastElementSelect <> invalid then m.lastElementSelect.setFocus(true)
    m.lastElementSelect = invalid
  end if
end sub

' Metodo que dispara el deslogueo del usuario
sub onLogoutEvent()
    m.carouselGuide.setFocus(true)
    __removeProgramDetailComponent()
    m.top.logout = true
    __clearGuide()
    m.top.logout = false
end sub

' Metodo que recarga el player con la nueva seleccion del objeto.
sub onStreamingPlayer()
    if m.programDetailComponent.programOpenInPlayer <> invalid and m.programDetailComponent.programOpenInPlayer <> "" then 
        program = ParseJson(m.programDetailComponent.programOpenInPlayer)
        
        m.top.selected = FormatJson({key: program.key, id: program.id, currentChannelId: program.channel.id, streamingAction: program.streamingAction})
    end if 
    __removeEmissionsComponent()
    __removeProgramDetailComponent()
end sub

' Metodo que dispara la apertura de la pantalla para eliminar sesiones concurrentes
sub onKillSession()
    printError("FaltaImplementar onKillSession")
    m.carouselGuide.setFocus(true)
    __removeProgramDetailComponent()
end sub

' Metodo que levanta la pantalla de detalle sobre el player.
sub onBackDetail()
    m.carouselGuide.setFocus(true)
    if (m.guideContainer.visible = false) then m.guideContainer.visible = true
    __removeEmissionsComponent()
    __removeProgramDetailComponent()
end sub

' Metodo que abre EmissionsScreen desde el detalle creado dentro de Guide.
sub onEmissions()
    if m.programDetailComponent = invalid then return
    if m.programDetailComponent.emissions = invalid or m.programDetailComponent.emissions = "" then return

    emissionsData = m.programDetailComponent.emissions
    m.programDetailComponent.emissions = invalid
    __loadEmissions(emissionsData)
end sub

' Metodo que vuelve de EmissionsScreen al detalle embebido en Guide.
sub onBackEmissions()
    if m.emissionsComponent = invalid then return

    if m.emissionsComponent.onBack then
        __removeEmissionsComponent()

        if m.programDetailComponent <> invalid then
            m.programDetailComponent.visible = true
            m.programDetailComponent.onFocus = true
            m.programDetailComponent.setFocus(true)
        else
            m.carouselGuide.setFocus(true)
            if (m.guideContainer.visible = false) then m.guideContainer.visible = true
        end if
    end if
end sub

' Reproduce una emision seleccionada desde EmissionsScreen sobre el player actual.
sub onStreamingEmissions()
    if m.emissionsComponent = invalid then return
    if m.emissionsComponent.streaming = invalid or m.emissionsComponent.streaming = "" then return

    streaming = ParseJson(m.emissionsComponent.streaming)
    if streaming <> invalid and streaming.key <> invalid and streaming.id <> invalid then
        currentChannelId = m.top.channelId
        if currentChannelId = invalid then currentChannelId = 0
        if m.currentChannel <> invalid and m.currentChannel.id <> invalid then currentChannelId = m.currentChannel.id
        m.top.selected = FormatJson({key: streaming.key, id: streaming.id, currentChannelId: currentChannelId, streamingAction: invalid})
    end if

    __removeEmissionsComponent()
    __removeProgramDetailComponent()
end sub

' Carga la configuracion inicial del componente, escuchando los observable y obteniendo las 
' referencias de compenentes necesarios para su uso
sub __initConfig()
    width = m.scaleInfo.width
    height = m.scaleInfo.height

    m.background.width = width
    m.background.height = height
    m.background.loadWidth = width
    m.background.loadHeight = height
    
    m.carouselGuideContainer.clippingRect = [0, 0, (width - scaleValue(250, m.scaleInfo)), m.size[1] + scaleValue(3, m.scaleInfo)]
    m.programSummaryPlayer.initConfig = true

    grayColor = m.global.colors.LIGHT_GRAY
    
    m.arrowUp.blendColor = grayColor
    m.arrowDown.blendColor = grayColor

    m.guideContainer.translation = [scaleValue(80, m.scaleInfo), (height - scaleValue(50, m.scaleInfo))]
    m.carouselContainer.translation = scaleSize([155,0], m.scaleInfo)
    
    if m.apiUrl = invalid then m.apiUrl = getConfigVariable(m.global.configVariablesKeys.API_URL)
    
    if (m.targetSet = invalid) then 
        m.targetSet = createObject("roSGNode", "TargetSet")
        m.targetSet.targetRects = m.targetRects
        m.targetSet.focusIndex = 4
    end if 

    m.selectedIndicator.size = scaleSize([152, 228], m.scaleInfo) 'Ajhuste del label y el espacio de separacion
    m.selectedIndicator.translation = scaleSize([539, 20], m.scaleInfo)

    m.channelContainer.width = scaleValue(145, m.scaleInfo)
    m.channelContainer.height = scaleValue(262, m.scaleInfo)
    m.channelContainer.translation = scaleSize([-30, 0], m.scaleInfo)
    m.guideGroup.translation = scaleSize([0, 40], m.scaleInfo)

    m.arrowUp.translation = scaleSize([90, 0], m.scaleInfo)
    m.arrowUp.width = scaleValue(70, m.scaleInfo)
    m.arrowUp.height = scaleValue(10, m.scaleInfo)

    m.prevContainer.translation = scaleSize([0, 25], m.scaleInfo)
    m.prevChannelNumber.width = scaleValue(80, m.scaleInfo)
    m.prevChannelNumber.height = scaleValue(30, m.scaleInfo)

    m.prevChannelImage.translation = scaleSize([110, 0], m.scaleInfo)
    m.prevChannelImage.width = scaleValue(30, m.scaleInfo)
    m.prevChannelImage.height = scaleValue(30, m.scaleInfo)

    m.currentChannelContainer.translation = scaleSize([0, 60], m.scaleInfo)

    m.currentChannelNumber.width = scaleValue(80, m.scaleInfo)
    m.currentChannelNumber.height = scaleValue(70, m.scaleInfo)

    m.currentChannelImage.translation = scaleSize([90, 0], m.scaleInfo)
    m.currentChannelImage.width = scaleValue(70, m.scaleInfo)
    m.currentChannelImage.height = scaleValue(70, m.scaleInfo)

    m.nextChannelContainer.translation = scaleSize([0, 145], m.scaleInfo)
    m.nextChannelNumber.width = scaleValue(80, m.scaleInfo)
    m.nextChannelNumber.height = scaleValue(30, m.scaleInfo)

    m.nextChannelImage.translation = scaleSize([110, 0], m.scaleInfo)
    m.nextChannelImage.width = scaleValue(30, m.scaleInfo)
    m.nextChannelImage.height = scaleValue(30, m.scaleInfo)

    m.arrowDown.translation = scaleSize([90, 200], m.scaleInfo)
    m.arrowDown.width = scaleValue(70, m.scaleInfo)
    m.arrowDown.height = scaleValue(10, m.scaleInfo)

    m.loadConfig = true
end sub

' Busca el canal pasado definido en el channelId sobre el arreglo de canales
sub __searchChannel()
    if m.channelArray.count() > 0 and m.top.channelId <> 0 then 
        for i = 0 to m.channelArray.count() - 1

            if m.top.channelIdIndexOf = -1 and m.top.channelId <> invalid and m.top.channelId <> 0 and m.top.channelId = m.channelArray[i].id then 
                m.top.channelIdIndexOf = i
    
                prevIndex = i - 1 
                nextIndex = i + 1 
                if prevIndex < 0 then prevIndex = m.channelArray.count() - 1
                if nextIndex > m.channelArray.count() - 1 then prevIndex = 0
    
                if m.channelArray[prevIndex] <> invalid then 
                    m.prevChannel = m.channelArray[prevIndex]
                    __updateChannelInfo(m.prevChannel, m.prevChannelNumber, m.prevChannelImage)
                end if
                 
                if m.channelArray[m.top.channelIdIndexOf] <> invalid then 
                    m.currentChannel = m.channelArray[m.top.channelIdIndexOf]
                    __updateChannelInfo(m.currentChannel, m.currentChannelNumber, m.currentChannelImage)
                end if
                
                if m.channelArray[nextIndex] <> invalid then 
                    m.nextChannel = m.channelArray[nextIndex]
                    __updateChannelInfo(m.nextChannel, m.nextChannelNumber, m.nextChannelImage)
                end if

                i = m.channelArray.count() - 1
            end if
        end for

        if m.top.visible then 
            if m.currentChannel <> invalid then
                m.currentChannelNumber.setFocus(true)
                __searchCurrentChannel()
            end if
        end if 
    end if 
end sub

' Limpia las variables y observables necesarios para el uso interno del componente.
sub __clearGuide()
    clearTimer(m.changeUp)
    clearTimer(m.changeDown)

    m.apiRequestCurrentChannel = clearApiRequest(m.apiRequestCurrentChannel)
    m.apiRequestPrevChannel = clearApiRequest(m.apiRequestPrevChannel)
    m.apiRequestNextChannel = clearApiRequest(m.apiRequestNextChannel)
    
    if m.carouselGuideEventsObserved then
        m.carouselGuide.unobserveField("itemFocused")
        m.carouselGuide.unobserveField("itemSelected")
        m.carouselGuide.unobserveField("happenedLeft")
        m.carouselGuide.unobserveField("happenedRight")
        m.carouselGuideEventsObserved = false
    end if

    m.currentCatchupHours = 0
    m.programSummaryPlayer.catchupDuration =  m.currentCatchupHours
    m.programSummaryPlayer.program = invalid

    m.carouselGuide.targetSet = invalid
    m.carouselGuide.content = invalid
    m.top.channelIdIndexOf = -1
    m.nextChannel = invalid
    m.currentChannel = invalid
    m.prevChannel = invalid
    m.isNowPosition = true
    m.indexPosition = 0
    m.dateTimeByPosition = invalid
    m.lastElementSelect = invalid
    
    m.selectedIndicator.visible = false

    m.channelArray = []
    m.nextCarouselGuide = invalid
    m.currentCarouselGuide = invalid
    m.prevCarouselGuide = invalid

    m.loadConfig = false
    m.saveDateByEvent = false

    m.prevChannelNumber.text = ""
    m.prevChannelImage.uri = ""
    
    m.currentChannelNumber.text = ""
    m.currentChannelImage.uri = ""
    
    m.nextChannelNumber.text = ""
    m.nextChannelImage.uri = ""

    if m.pinDialog <> invalid then
        m.programBySend = invalid
        clearPINDialogAndGetOption(m.top, m.pinDialog)
        m.pinDialog = invalid
    end if

    if m.dialog <> invalid then
        clearDialogAndGetOption(m.top, m.dialog)
        m.dialog = invalid 
    end if 

    __removeProgramDetailComponent()
end sub

' Realiza la busca la guia del canal actual
sub __searchCurrentChannel()
    m.apiRequestCurrentChannel = sendApiRequest(m.apiRequestCurrentChannel, urlEpgCarouselGuide(m.currentChannel.id), "GET", "onCurrentCarouselResponse", invalid, invalid, invalid, false, FormatJson({channelId: m.currentChannel.id}))
end sub

' Realiza la busca la guia del canal anterior
sub __searchPrevChannel() 
    m.apiRequestPrevChannel = sendApiRequest(m.apiRequestPrevChannel, urlEpgCarouselGuide(m.prevChannel.id), "GET", "onPrevCarouselResponse", invalid, invalid, invalid, false, FormatJson({channelId: m.prevChannel.id}))
end sub

' Realiza la busca la guia del canal siguiente
sub __searchNextChannel() 
    m.apiRequestNextChannel = sendApiRequest(m.apiRequestNextChannel, urlEpgCarouselGuide(m.nextChannel.id), "GET", "onNextCarouselResponse", invalid, invalid, invalid, false, FormatJson({channelId: m.nextChannel.id}))
end sub

' Función para configurar un TargetList con su TargetSet y contenido
sub __setupTargetList(content as Object)
    ' Genera las posiciones de los targets dinámicamente según la cantidad de items
    m.carouselGuide.targetSet = m.targetSet
    m.carouselGuide.content = content
    m.carouselGuide.itemComponentName = "GuideSingleItem"
    m.carouselGuide.showTargetRects = false

    if not m.carouselGuideEventsObserved then
        m.carouselGuide.observeField("itemSelected", "onItemSelectedChanged")
        m.carouselGuide.observeField("itemFocused", "onItemFocusedChanged")
        m.carouselGuide.observeField("happenedLeft", "onLeftEvent")
        m.carouselGuide.observeField("happenedRight", "onRightEvent")
        m.carouselGuideEventsObserved = true
    end if
end sub

' Selecciona un canal enviandolo al player para reproducir o levantando el modal de control 
' parental si el canal lo requiere
sub __channelSelected()
    if m.currentChannel.parentalControl <> invalid and m.currentChannel.parentalControl then
        'm.lastElementSelect = m.top.focusedChild
        'if m.pinDialog <> invalid then
            'm.programBySend = invalid
            'clearPINDialogAndGetOption(m.top, m.pinDialog)
            'm.pinDialog = invalid
        'end if
        'm.pinDialog = createAndShowPINDialog(m.top, i18n_t(m.global.i18n, "shared.parentalControlModal.title"), "onPinDialogLoad", [i18n_t(m.global.i18n, "button.ok"), i18n_t(m.global.i18n, "button.cancel")])
        __loadStreamingForPlayer()
    else
        __loadStreamingForPlayer()
    end if
end sub

' Procesa y carga la lista de programa del canal que actualmente tiene el foco
sub __processAndLoadCarousel(programs)
    contentRoot = createObject("roSGNode", "ProgramNode")
    startTime = CreateObject("roDateTime")
    endTime = CreateObject("roDateTime")
    now = CreateObject("roDateTime")
    now.ToLocalTime()
    nowSeconds = now.AsSeconds()
    index = 0
    lastItem = programs.count() - 1

    channelName = ""
    channelCategory = ""
    
    if m.currentChannel <> invalid then
        if m.currentChannel.name <> invalid and  m.currentChannel.name <> "" then
        channelName = m.currentChannel.name
        end if
        
        if m.currentChannel.category <> invalid and m.currentChannel.category <> "" then
        channelCategory = m.currentChannel.category
        end if
    end if

    m.noProgram = false

    if m.currentCarouselGuide.data <> invalid and m.currentCarouselGuide.data.programs.count() = 0 then 

        currentChannelProgram = {}
        currentChannelProgram.key = "ChannelId"
        currentChannelProgram.id = m.currentChannel.id
        currentChannelProgram.title = m.currentChannel.name
        currentChannelProgram.isNow = true
        currentChannelProgram.imageURL = invalid
        currentChannelProgram.programTime = invalid
        currentChannelProgram.formattedDuration = invalid
        currentChannelProgram.durationInMinutes = invalid
        currentChannelProgram.startTime = invalid
        currentChannelProgram.endTime = invalid
        currentChannelProgram.parentalControl = m.currentChannel.parentalControl

        m.currentCarouselGuide.data.programs.Push(currentChannelProgram)

        m.noProgram = true
    end if

    for each program in programs
        child = contentRoot.createChild("ProgramNode")
        child.size = scaleSize([153, 230], m.scaleInfo)
        if program.key <> invalid then child.key = program.key
        if program.id <> invalid then child.id = program.id
        if program.title <> invalid and program.title <> "" then child.title = program.title
        if program.subtitle <> invalid and program.subtitle <> "" then child.subtitle = program.subtitle
        if program.synopsis <> invalid and program.synopsis <> "" then child.synopsis = program.synopsis
        if program.category <> invalid and program.category.name <> invalid and program.category.name <> "" then child.categoryName = program.category.name
        if program.formattedDuration <> invalid then child.formattedDuration = program.formattedDuration
        if program.durationInMinutes <> invalid then child.durationInMinutes = program.durationInMinutes
        if program.image <> invalid then child.imageURL = getImageUrl(program.image)

        if program.parentalControl <> invalid then 
            child.parentalControl = program.parentalControl
        else if m.currentChannel.parentalControl <> invalid then 
            child.parentalControl = m.currentChannel.parentalControl
        end if 
        
        program.channelName = channelName
        program.channelCategory = channelCategory

        if program.startTime <> invalid then 
            startTime.FromISO8601String(program.startTime)
            startTime.ToLocalTime()

            child.startTime = program.startTime
            child.startSeconds = startTime.AsSeconds()
            
            child.programTime = dateConverter(startTime, i18n_t(m.global.i18n, "time.formatHours"))
        end if

        if program.endTime <> invalid then 
            endTime.FromISO8601String(program.endTime)
            endTime.ToLocalTime()

            child.endTime = program.endTime 
            child.endSeconds = endTime.AsSeconds()
        end if

        if program.endTime <> invalid and program.startTime <> invalid then
            startSeconds = startTime.AsSeconds()
            endSeconds = endTime.AsSeconds()

            if (startSeconds <= nowSeconds and endSeconds >= nowSeconds) then 
                child.programTime = i18n_t(m.global.i18n, "player.guide.now")
                child.isNow = true
                if m.isNowPosition then m.indexPosition = index
            end if
            
            if not m.isNowPosition and m.dateTimeByPosition <> invalid then
                if (startSeconds <= m.dateTimeByPosition and endSeconds >= m.dateTimeByPosition) then 
                    m.indexPosition = index
                else if (index = 0) and m.dateTimeByPosition < startSeconds then 
                    m.indexPosition = 0
                else if (index = lastItem) and m.dateTimeByPosition > endSeconds then 
                    m.indexPosition = lastItem
                end if
                
            end if
        else if (program.endTime = invalid and program.startTime = invalid and program.isNow = true) then
            child.programTime = i18n_t(m.global.i18n, "player.guide.now")
            child.isNow = true
            if m.isNowPosition then m.indexPosition = index
        end if

        index++
    end for


    __setupTargetList(contentRoot)

    if (m.noProgram = true) then
        m.carouselGuide.jumpToItem = 0
    else
        m.carouselGuide.jumpToItem = m.indexPosition
    end if
    
    
    if m.lastElementSelect <> invalid then
        m.lastElementSelect = m.carouselGuide
    else 
        m.carouselGuide.setFocus(true)
    end if
    
    m.selectedIndicator.visible = true
end sub

' Actualiza la informacion del canal en pantalla 
sub __updateChannelInfo(channel, roElementNumber, roElementImage)
    if channel = invalid then return
    if channel.number <> invalid then 
        roElementNumber.text = channel.number.ToStr()
    else
        roElementNumber.text = ""
    end if 
    
    if channel.image <> invalid then
        roElementImage.uri = getImageUrl(channel.image)
    else
        roElementImage.uri = ""
    end if 
end sub

' Notifica al player que se a selecionado un nuevo programa para reproducir
sub __loadStreamingForPlayer()
    if m.programBySend <> invalid then 
        ' Seleccion por programa
        m.top.selected = FormatJson({key: m.programBySend.key, id: m.programBySend.id, currentChannelId: m.currentChannel.id, streamingAction: invalid})
    else if m.currentChannel <> invalid then 
        ' Seleccion por canal
        m.top.selected = FormatJson({key: "ChannelId", id: m.currentChannel.id, currentChannelId: m.currentChannel.id, streamingAction: invalid})
    end if 
end sub

' Define y muestra el detalle de un programa como modal
sub __loadDetail()
    __removeProgramDetailComponent()
    m.programDetailComponent = m.detailGuideContainer.createChild("ProgramDetailScreen")

    m.programDetailComponent.isOpenByPlayer = true
    m.programDetailComponent.loading = m.top.loading
    
    m.programDetailComponent.observeField("logout", "onLogoutEvent")
    m.programDetailComponent.observeField("programOpenInPlayer", "onStreamingPlayer")
    m.programDetailComponent.observeField("pendingStreamingSession", "onKillSession")
    m.programDetailComponent.observeField("onBack", "onBackDetail")
    m.programDetailComponent.observeField("emissions", "onEmissions")

    ' Se acomoda para que lo interprete la pantalal de detalle
    m.programBySend.redirectKey = m.programBySend.key
    m.programBySend.redirectId = m.programBySend.id
    
    m.programDetailComponent.onFocus = true
    m.programDetailComponent.setFocus(true)
    m.programDetailComponent.data = FormatJson(m.programBySend)
    m.guideContainer.visible = false
end sub

' Define y muestra EmissionsScreen como modal sobre el player.
sub __loadEmissions(emissionsData as string)
    __removeEmissionsComponent()

    if m.programDetailComponent <> invalid then
        m.programDetailComponent.onFocus = false
        m.programDetailComponent.visible = false
    end if

    m.emissionsComponent = m.detailGuideContainer.createChild("EmissionsScreen")
    m.emissionsComponent.loading = m.top.loading
    m.emissionsComponent.observeField("onBack", "onBackEmissions")
    m.emissionsComponent.observeField("streaming", "onStreamingEmissions")
    m.emissionsComponent.observeField("logout", "onLogoutEvent")
    m.emissionsComponent.onFocus = true
    m.emissionsComponent.setFocus(true)
    m.emissionsComponent.data = emissionsData
end sub

' Guarda la posicion donde se decidio deplazar hacia arriba o abajo para mantener 
' la misma linea temporal al cambiar entre canales de la guia
sub __savePosition()
    if m.saveDateByEvent then
        if m.carouselGuide <> invalid and m.carouselGuide.itemFocused <> invalid and m.carouselGuide.content <> invalid then 
            node = m.carouselGuide.content.getChild(m.carouselGuide.itemFocused)
            if node <> invalid then 
                if node.isNow then
                    m.isNowPosition = true
                    m.dateTimeByPosition = invalid
                else 
                    m.isNowPosition = false
                    m.dateTimeByPosition = node.startSeconds
                end if
            end if 
        end if
    end if
    m.saveDateByEvent = false
end sub

' Limpia el modal del detalle de programa que se abrio sobre el player.
sub __removeProgramDetailComponent()
    __removeEmissionsComponent()

    if m.programDetailComponent <> invalid then 
        m.detailGuideContainer.removeChild(m.programDetailComponent)
        m.programDetailComponent.unobserveField("logout")
        m.programDetailComponent.unobserveField("programOpenInPlayer")
        m.programDetailComponent.unobserveField("pendingStreamingSession")
        m.programDetailComponent.unobserveField("onBack")
        m.programDetailComponent.unobserveField("emissions")
        m.programDetailComponent.onFocus = false
        m.programDetailComponent.data = invalid
        m.programDetailComponent.isOpenByPlayer = false
        m.programDetailComponent.loading = invalid
        m.programDetailComponent.programOpenInPlayer = invalid
        m.programDetailComponent.emissions = invalid
    end if
    m.programDetailComponent = invalid
    m.guideContainer.visible = true
end sub

' Limpia EmissionsScreen embebido dentro de Guide.
sub __removeEmissionsComponent()
    if m.emissionsComponent <> invalid then
        m.detailGuideContainer.removeChild(m.emissionsComponent)
        m.emissionsComponent.unobserveField("onBack")
        m.emissionsComponent.unobserveField("streaming")
        m.emissionsComponent.unobserveField("logout")
        m.emissionsComponent.onFocus = false
        m.emissionsComponent.data = invalid
        m.emissionsComponent.loading = invalid
        m.emissionsComponent.streaming = invalid
        m.emissionsComponent.onBack = false
    end if
    m.emissionsComponent = invalid
end sub